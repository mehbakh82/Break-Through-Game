from player import Player


class AlphaBetaPlayer(Player):
    def __init__(self, player_number, board, depth=3):
        super().__init__(player_number, board)
        self.depth = depth
        
    def get_scores(self, board):
        scores = {0: 0, 1: 0}
        for row in range(6):
            for col in range(6):
                if board[row][col] == 0:
                    scores[0] += 1 + (2.0 ** row) * row
                elif board[row][col] == 1:
                    scores[1] += 1 + (2.0 ** (6 - row - 1)) * (6 - row - 1)
        scores[0] += self.board.winning_score(board, 0)
        scores[1] += self.board.winning_score(board, 1)
        return scores
                
    def get_next_move(self):
        max_score = -float('inf')
        best_move = None
        for move, i, j, dx, dy in self.get_possible_moves(self.player_number):
            self.board.start_imagination()
            self.board.place_piece_imaginary(move, self.player_number)
            score = self.alphabeta(depth=1, alpha=-float('inf'), beta=float('inf'))
            if score > max_score:
                max_score = score
                best_move = move
        return best_move
        
    def alphabeta(self, depth, alpha, beta):
        board = self.board.get_imaginary_board()
        if self.board.is_game_over(board) != -1 or depth == self.depth:
            scores = self.get_scores(board)
            return scores[self.player_number] - scores[self.opponent_number]
        
        if depth % 2 == 0:
            max_score = -float('inf')
            for move, i, j, dx, dy in self.get_possible_moves(self.player_number):
                previous_destination_value = board[i][j]
                self.board.place_piece_imaginary(move, self.player_number)
                score = self.alphabeta(depth + 1, alpha, beta)
                max_score = max(max_score, score)
                board[i][j] = previous_destination_value
                board[i + dx][j + dy] = 0
                if score >= beta:
                    return max_score
                alpha = max(alpha, score)
            return max_score
        else:
            min_score = float('inf')
            for move, i, j, dx, dy in self.get_possible_moves(self.opponent_number):
                previous_destination_value = board[i][j]
                self.board.place_piece_imaginary(move, self.opponent_number)
                score = self.alphabeta(depth + 1, alpha, beta)
                min_score = min(min_score, score)
                board[i][j] = previous_destination_value
                board[i + dx][j + dy] = 1
                if score <= alpha:
                    return min_score
                beta = min(beta, score)
            return min_score
        
    def get_possible_moves(self, player_number):
        moves = []
        range_n = (0, self.board.get_n()) if player_number == self.player_number else (self.board.get_n() - 1, -1)
        step = 1 if player_number == self.player_number else -1

        board = self.board.get_imaginary_board()
        if board is None:
            return moves
        
        for i in range(range_n[0], range_n[1], step):
            for j in range(range_n[0], range_n[1], step):
                if board[i][j] == player_number:
                    for direction in self.board.get_possible_directions(player_number):
                        move = (i, j), (i + direction[0], j + direction[1])
                        if self.board.is_move_valid(board, move, player_number):
                            moves.append((move, i, j, direction[0], direction[1]))
        return moves