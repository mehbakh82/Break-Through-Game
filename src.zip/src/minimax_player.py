from player import Player


class MinimaxPlayer(Player):
    def __init__(self, player_number, board, depth=3):
        super().__init__(player_number, board)
        self.depth = depth

    def get_next_move(self):
        best_move, _ = self.minimax(self.depth, self.player_number, True)
        return best_move

    def minimax(self, depth, player, maximizing_player):
        if depth == 0 or self.board.is_game_over(self.board.get_board_grid()) != -1:
            return None, self.evaluate_board()

        if maximizing_player:
            max_score = float('-inf')
            best_move = None
            for move in self.get_possible_moves(player):
                self.board.start_imagination()
                self.board.place_piece_imaginary(move, player)
                _, score = self.minimax(depth - 1, self.opponent_number, False)
                if score > max_score:
                    max_score = score
                    best_move = move
            return best_move, max_score
        else:
            min_score = float('inf')
            best_move = None
            for move in self.get_possible_moves(player):
                self.board.start_imagination()
                self.board.place_piece_imaginary(move, player)
                _, score = self.minimax(depth - 1, self.opponent_number, True)
                if score < min_score:
                    min_score = score
                    best_move = move
            return best_move, min_score

    def evaluate_board(self):
        scores = self.board.get_scores(self.board.get_board_grid())
        return scores[self.player_number] - scores[self.opponent_number]

    def get_possible_moves(self, player):
        moves = []
        range_n = (0, self.board.get_n()) if player == self.player_number else (self.board.get_n() - 1, -1)
        step = 1 if player == self.player_number else -1
        for i in range(range_n[0], range_n[1], step):
            for j in range(self.board.get_n()):
                if self.board.get_board_grid()[i][j] == player:
                    for direction in self.board.get_possible_directions(player):
                        move = ((i, j), (i + direction[0], j + direction[1]))
                        if self.board.is_move_valid(self.board.get_board_grid(), move, player):
                            moves.append(move)
        return moves
